import '../styles/Header.css'
function Header() {
    return (
      <div className="Header">
        <h1>WHE WHE on D' Avenue</h1>
      </div>
    );
  }
  
  export default Header;